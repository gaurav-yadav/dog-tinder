import assert from "node:assert/strict";
import test from "node:test";
import { midpoint } from "../src/video.js";

test("midpoint halves a valid video duration", () => {
  assert.equal(midpoint(11.5), 5.75);
});

test("midpoint rejects invalid durations", () => {
  assert.throws(() => midpoint(0), /duration/);
  assert.throws(() => midpoint(Number.NaN), /duration/);
});
