const form = document.querySelector("#puppy-form");
const result = document.querySelector("#result");
const status = document.querySelector("#status");
const image = result.querySelector("img");
const loader = result.querySelector(".loader");
let imageUrl;

document.querySelectorAll('input[type="file"]').forEach((input) => {
  input.addEventListener("change", () => {
    const file = input.files?.[0];
    if (!file) return;
    const card = input.closest(".upload-card");
    const video = card.querySelector("video");
    video.src = URL.createObjectURL(file);
    video.currentTime = 0.1;
    card.classList.add("has-video");
  });
});

form.addEventListener("submit", async (event) => {
  event.preventDefault();
  const button = form.querySelector("button");
  button.disabled = true;
  result.hidden = false;
  image.style.display = "none";
  loader.style.display = "block";
  status.textContent = "Finding both middle frames, then imagining their puppy. This usually takes 15–40 seconds…";
  result.scrollIntoView({ behavior: "smooth" });

  try {
    const response = await fetch("/api/generate", { method: "POST", body: new FormData(form) });
    if (!response.ok) {
      const body = await response.json().catch(() => ({}));
      throw new Error(body.error || "Generation failed. Please try again.");
    }
    if (imageUrl) URL.revokeObjectURL(imageUrl);
    imageUrl = URL.createObjectURL(await response.blob());
    image.src = imageUrl;
    await image.decode();
    loader.style.display = "none";
    image.style.display = "block";
    status.textContent = "A fictional blend inspired equally by both dogs.";
  } catch (error) {
    loader.style.display = "none";
    status.textContent = error.message;
  } finally {
    button.disabled = false;
  }
});

document.querySelector("#again").addEventListener("click", () => {
  result.hidden = true;
  window.scrollTo({ top: 0, behavior: "smooth" });
});
