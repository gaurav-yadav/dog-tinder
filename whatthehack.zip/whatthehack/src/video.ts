import { spawn } from "node:child_process";
import { readFile } from "node:fs/promises";
import { createRequire } from "node:module";

const require = createRequire(import.meta.url);
const ffmpegPath = require("ffmpeg-static") as string | null;
const ffprobe = require("ffprobe-static") as { path: string };

function run(command: string, args: string[]): Promise<string> {
  return new Promise((resolve, reject) => {
    const child = spawn(command, args, { stdio: ["ignore", "pipe", "pipe"] });
    let stdout = "";
    let stderr = "";
    child.stdout.on("data", (chunk) => (stdout += chunk));
    child.stderr.on("data", (chunk) => (stderr += chunk));
    child.once("error", reject);
    child.once("close", (code) => {
      if (code === 0) resolve(stdout.trim());
      else reject(new Error(stderr.trim() || `Media command exited ${code}`));
    });
  });
}

export function midpoint(durationSeconds: number): number {
  if (!Number.isFinite(durationSeconds) || durationSeconds <= 0) {
    throw new Error("The uploaded video has no readable duration.");
  }
  return durationSeconds / 2;
}

export async function extractMiddleFrame(
  videoPath: string,
  outputPath: string,
): Promise<Buffer> {
  if (!ffmpegPath) throw new Error("FFmpeg binary is unavailable.");

  const rawDuration = await run(ffprobe.path, [
    "-v",
    "error",
    "-show_entries",
    "format=duration",
    "-of",
    "default=noprint_wrappers=1:nokey=1",
    videoPath,
  ]);
  const seek = midpoint(Number(rawDuration)).toFixed(3);

  await run(ffmpegPath, [
    "-hide_banner",
    "-loglevel",
    "error",
    "-ss",
    seek,
    "-i",
    videoPath,
    "-frames:v",
    "1",
    "-vf",
    "scale='min(1024,iw)':-2",
    "-q:v",
    "2",
    "-y",
    outputPath,
  ]);
  return readFile(outputPath);
}
