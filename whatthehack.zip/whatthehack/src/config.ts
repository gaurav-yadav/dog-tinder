import "dotenv/config";

export const config = {
  port: Number(process.env.PORT ?? 3000),
  apiKey: process.env.OPENROUTER_API_KEY ?? "",
  imageModel:
    process.env.OPENROUTER_IMAGE_MODEL ?? "bytedance-seed/seedream-4.5",
};

export function assertConfigured(): void {
  if (!config.apiKey || config.apiKey.includes("dummy")) {
    throw new Error(
      "Set a real OPENROUTER_API_KEY in .env before generating an image.",
    );
  }
}
