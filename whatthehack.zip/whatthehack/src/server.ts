import crypto from "node:crypto";
import { mkdir, rm } from "node:fs/promises";
import path from "node:path";
import express from "express";
import multer from "multer";
import { assertConfigured, config } from "./config.js";
import { generatePuppy } from "./openrouter.js";
import { extractMiddleFrame } from "./video.js";

const app = express();
const publicDir = path.resolve("public");
const tempRoot = path.resolve("tmp");
await mkdir(tempRoot, { recursive: true });

const upload = multer({
  dest: tempRoot,
  limits: { fileSize: 100 * 1024 * 1024, files: 2 },
  fileFilter: (_request, file, done) => {
    done(null, file.mimetype.startsWith("video/"));
  },
});

app.use(express.static(publicDir));

app.post(
  "/api/generate",
  upload.fields([
    { name: "dogOne", maxCount: 1 },
    { name: "dogTwo", maxCount: 1 },
  ]),
  async (request, response) => {
    const files = request.files as Record<string, Express.Multer.File[]> | undefined;
    const first = files?.dogOne?.[0];
    const second = files?.dogTwo?.[0];
    const jobDir = path.join(tempRoot, crypto.randomUUID());

    try {
      assertConfigured();
      if (!first || !second) throw new Error("Please upload two valid video files.");
      await mkdir(jobDir, { recursive: true });
      const [firstFrame, secondFrame] = await Promise.all([
        extractMiddleFrame(first.path, path.join(jobDir, "dog-one.jpg")),
        extractMiddleFrame(second.path, path.join(jobDir, "dog-two.jpg")),
      ]);
      const image = await generatePuppy(firstFrame, secondFrame);
      response.type(image.mediaType).send(image.bytes);
    } catch (error) {
      const message = error instanceof Error ? error.message : "Generation failed.";
      response.status(message.includes("OPENROUTER_API_KEY") ? 503 : 400).json({ error: message });
    } finally {
      await Promise.allSettled([
        first ? rm(first.path, { force: true }) : Promise.resolve(),
        second ? rm(second.path, { force: true }) : Promise.resolve(),
        rm(jobDir, { recursive: true, force: true }),
      ]);
    }
  },
);

app.use((error: unknown, _request: express.Request, response: express.Response, _next: express.NextFunction) => {
  const message = error instanceof Error ? error.message : "Upload failed.";
  response.status(400).json({ error: message });
});

app.listen(config.port, () => {
  console.log(`Puppy Preview is running at http://localhost:${config.port}`);
});
