import { config } from "./config.js";

type ImageResponse = {
  data?: Array<{ b64_json?: string; media_type?: string }>;
  error?: { message?: string };
};

const prompt = `Create one photorealistic, wholesome studio portrait of a fictional puppy that plausibly blends visible traits from BOTH reference dogs: coat colors and markings, fur length and texture, ear shape, muzzle, and overall build. Give each parent balanced influence. Show only one healthy puppy, centered, looking at the camera, soft natural light, simple warm neutral background, detailed fur, no collar, no text, no watermark. This is a playful artistic visualization, not a genetic prediction.`;

export async function generatePuppy(
  firstFrame: Buffer,
  secondFrame: Buffer,
): Promise<{ bytes: Buffer; mediaType: string }> {
  const response = await fetch("https://openrouter.ai/api/v1/images", {
    method: "POST",
    headers: {
      Authorization: `Bearer ${config.apiKey}`,
      "Content-Type": "application/json",
      "HTTP-Referer": "http://localhost:3000",
      "X-Title": "Puppy Preview",
    },
    body: JSON.stringify({
      model: config.imageModel,
      prompt,
      // Seedream advertises 1K, but rejects 1024x1024 because it requires
      // at least 3,686,400 output pixels. 2K is its smallest valid square.
      resolution: "2K",
      aspect_ratio: "1:1",
      n: 1,
      input_references: [firstFrame, secondFrame].map((frame) => ({
        type: "image_url",
        image_url: { url: `data:image/jpeg;base64,${frame.toString("base64")}` },
      })),
    }),
    signal: AbortSignal.timeout(120_000),
  });

  const payload = (await response.json()) as ImageResponse;
  if (!response.ok) {
    throw new Error(payload.error?.message ?? `OpenRouter returned ${response.status}`);
  }
  const generated = payload.data?.[0];
  if (!generated?.b64_json) throw new Error("OpenRouter returned no image.");

  return {
    bytes: Buffer.from(generated.b64_json, "base64"),
    mediaType: generated.media_type ?? "image/png",
  };
}
