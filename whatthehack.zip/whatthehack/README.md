# Puppy Preview

A TypeScript/Node.js web app that takes two dog videos, extracts the midpoint frame from each, and asks an OpenRouter image model to create a playful fictional puppy portrait inspired by both dogs.

## Requirements

- Node.js 20+
- An OpenRouter API key with credits

FFmpeg and FFprobe are installed as npm dependencies, so system-level installs are not required on common platforms.

## Run locally

```bash
npm install
cp .env.example .env
# Replace the placeholder OPENROUTER_API_KEY in .env
npm run dev
```

Open <http://localhost:3000>. Uploads are limited to two 100 MB video files. Temporary uploads and extracted frames are deleted after each request.

## Production

```bash
npm run build
npm start
```

The default model is `bytedance-seed/seedream-4.5`, using its smallest valid square output (`2K`). Although OpenRouter lists a `1K` tier, Seedream rejects a 1024×1024 request because it falls below the model's minimum output-pixel count. The result is an artistic visualization, not a prediction of real genetics or breeding outcomes.
